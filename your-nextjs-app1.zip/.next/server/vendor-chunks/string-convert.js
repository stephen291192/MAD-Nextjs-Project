"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
exports.id = "vendor-chunks/string-convert";
exports.ids = ["vendor-chunks/string-convert"];
exports.modules = {

/***/ "(ssr)/./node_modules/string-convert/camel2hyphen.js":
/*!*****************************************************!*\
  !*** ./node_modules/string-convert/camel2hyphen.js ***!
  \*****************************************************/
/***/ ((module) => {

eval("\nvar camel2hyphen = function(str) {\n    return str.replace(/[A-Z]/g, function(match) {\n        return \"-\" + match.toLowerCase();\n    }).toLowerCase();\n};\nmodule.exports = camel2hyphen;\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHNzcikvLi9ub2RlX21vZHVsZXMvc3RyaW5nLWNvbnZlcnQvY2FtZWwyaHlwaGVuLmpzIiwibWFwcGluZ3MiOiI7QUFBQSxJQUFJQSxlQUFlLFNBQVVDLEdBQUc7SUFDOUIsT0FBT0EsSUFDRUMsT0FBTyxDQUFDLFVBQVUsU0FBVUMsS0FBSztRQUNoQyxPQUFPLE1BQU1BLE1BQU1DLFdBQVc7SUFDaEMsR0FDQ0EsV0FBVztBQUN0QjtBQUVBQyxPQUFPQyxPQUFPLEdBQUdOIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8veW91ci1uZXh0anMtYXBwLy4vbm9kZV9tb2R1bGVzL3N0cmluZy1jb252ZXJ0L2NhbWVsMmh5cGhlbi5qcz82ZTgwIl0sInNvdXJjZXNDb250ZW50IjpbInZhciBjYW1lbDJoeXBoZW4gPSBmdW5jdGlvbiAoc3RyKSB7XG4gIHJldHVybiBzdHJcbiAgICAgICAgICAucmVwbGFjZSgvW0EtWl0vZywgZnVuY3Rpb24gKG1hdGNoKSB7XG4gICAgICAgICAgICByZXR1cm4gJy0nICsgbWF0Y2gudG9Mb3dlckNhc2UoKTtcbiAgICAgICAgICB9KVxuICAgICAgICAgIC50b0xvd2VyQ2FzZSgpO1xufTtcblxubW9kdWxlLmV4cG9ydHMgPSBjYW1lbDJoeXBoZW47Il0sIm5hbWVzIjpbImNhbWVsMmh5cGhlbiIsInN0ciIsInJlcGxhY2UiLCJtYXRjaCIsInRvTG93ZXJDYXNlIiwibW9kdWxlIiwiZXhwb3J0cyJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(ssr)/./node_modules/string-convert/camel2hyphen.js\n");

/***/ })

};
;